package gay.xujun.whim.armor;

import com.mojang.blaze3d.vertex.PoseStack;
import gay.xujun.whim.client.models.anubis.*;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class CustomArmorRenderer implements ArmorRenderer {
    private final AnubisHelmetModel<HumanoidRenderState> helmetModel;
    private final AnubisChestPlateModel<HumanoidRenderState> chestplateModel;
    private final AnubisLegginsModel<HumanoidRenderState> leggingsModel;
    private final AnubisBootsModel<HumanoidRenderState> bootsModel;
    private final Identifier texture;

    public CustomArmorRenderer() {
        this.helmetModel = new AnubisHelmetModel<>(AnubisHelmetModel.createLayerDefinition().bakeRoot(), false);
        this.chestplateModel = new AnubisChestPlateModel<>(AnubisChestPlateModel.createLayerDefinition().bakeRoot(), false);
        this.leggingsModel = new AnubisLegginsModel<>(AnubisLegginsModel.createLayerDefinition().bakeRoot(), false);
        this.bootsModel = new AnubisBootsModel<>(AnubisBootsModel.createLayerDefinition().bakeRoot(), false);
        this.texture = Identifier.fromNamespaceAndPath("whim", "textures/models/armor/anubis_armor.png");
    }

    @Override
    public void render(PoseStack matrices, SubmitNodeCollector vertexConsumers, ItemStack stack, HumanoidRenderState renderState, EquipmentSlot slot, int light, HumanoidModel<HumanoidRenderState> contextModel) {
        ArmorModel<HumanoidRenderState> model = null;
        if (slot == EquipmentSlot.HEAD) {
            model = this.helmetModel;
        } else if (slot == EquipmentSlot.CHEST) {
            model = this.chestplateModel;
        } else if (slot == EquipmentSlot.LEGS) {
            model = this.leggingsModel;
        } else if (slot == EquipmentSlot.FEET) {
            model = this.bootsModel;
        }

        if (model == null) return;

        model.setupAnim(renderState);
        vertexConsumers.order(0).submitModel(model, renderState, matrices, RenderTypes.armorCutoutNoCull(this.texture), light, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF, null, renderState.outlineColor, null);
    }
}
