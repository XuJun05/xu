package gay.xujun.whim.client.models.anubis;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import gay.xujun.whim.armor.ArmorModel;

public class AnubisBootsModel<T extends HumanoidRenderState> extends ArmorModel<T> {

    public AnubisBootsModel(ModelPart root, boolean isSlim) {
        super(root, isSlim);
    }

    public static LayerDefinition createLayerDefinition() {
        MeshDefinition meshdefinition = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = meshdefinition.getRoot();
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror()
                        .texOffs(93, 14).addBox(-2.5F, 7.4F, -2.5F, 5.0F, 3.0F, 5.0F, new CubeDeformation(-0.2F)),
                PartPose.ZERO);

        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(93, 14).addBox(-2.5F, 7.4F, -2.5F, 5.0F, 3.0F, 5.0F, new CubeDeformation(-0.2F)),
                PartPose.ZERO);

        return LayerDefinition.create(meshdefinition, 128, 64);
    }

    @Override
    protected void setupArmorPartAnim(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {}
}
