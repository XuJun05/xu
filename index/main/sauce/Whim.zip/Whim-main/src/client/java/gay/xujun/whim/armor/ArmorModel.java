package gay.xujun.whim.armor;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.util.Mth;

public abstract class ArmorModel<T extends HumanoidRenderState> extends HumanoidModel<T> {
    public final boolean isSlim;

    public ArmorModel(ModelPart root, boolean isSlim) {
        super(root);
        this.isSlim = isSlim;
    }

    protected abstract void setupArmorPartAnim(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch);

    @Override
    public void setupAnim(T renderState) {
        super.setupAnim(renderState);
        this.setupArmorPartAnim(0.0F, 0.0F, renderState.ageInTicks, renderState.yRot, renderState.xRot);
    }

    public static float sinPI(float f) { return Mth.sin(f * (float) Math.PI); }
    public static float cosPI(float f) { return Mth.cos(f * (float) Math.PI); }
}
