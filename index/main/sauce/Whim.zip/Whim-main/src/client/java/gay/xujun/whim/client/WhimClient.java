package gay.xujun.whim.client;

import gay.xujun.whim.armor.CustomArmorRenderer;
import gay.xujun.whim.registry.ItemRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;

public class WhimClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        CustomArmorRenderer renderer = new CustomArmorRenderer();
        ArmorRenderer.register(renderer,
                ItemRegistry.ANUBIS_HELMET,
                ItemRegistry.ANUBIS_CHESTPLATE,
                ItemRegistry.ANUBIS_LEGGINGS,
                ItemRegistry.ANUBIS_BOOTS
        );
    }
}