package gay.xujun.whim.registry;

import gay.xujun.whim.Whim;
import gay.xujun.whim.block.PlushBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.function.Function;

public class BlockRegistry {

    public static final Block TEST_BLOCK = register("test_block", Block::new, BlockBehaviour.Properties.of());
    public static final Block RED_FUNDOSHI_BLOCK = register("red_fundoshi_block", PlushBlock::new, BlockBehaviour.Properties.of());
    public static final Block WHITE_FUNDOSHI_BLOCK = register("white_fundoshi_block", PlushBlock::new, BlockBehaviour.Properties.of());
    public static final Block BLACK_BRIEF_BLOCK = register("black_brief_block", PlushBlock::new, BlockBehaviour.Properties.of());
    public static final Block WHITE_BRIEF_BLOCK = register("white_brief_block", PlushBlock::new, BlockBehaviour.Properties.of());
    public static final Block NUDE_BLOCK = register("nude_block", PlushBlock::new, BlockBehaviour.Properties.of());

    public static <T extends Block> T register(String name, Function<BlockBehaviour.Properties, T> blockFactory, BlockBehaviour.Properties setting){
        ResourceKey<Block> blockkey = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(Whim.MOD_ID, name));
        T block = blockFactory.apply(setting.setId(blockkey));
        Registry.register(BuiltInRegistries.BLOCK, blockkey, block);
        return block;
    }

    public static void registerBlock(){
        Whim.LOGGER.info("Registering Block");
    }
}