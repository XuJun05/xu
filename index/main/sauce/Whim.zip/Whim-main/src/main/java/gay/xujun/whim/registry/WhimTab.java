package gay.xujun.whim.registry;

import gay.xujun.whim.Whim;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class WhimTab {
    public static final ResourceKey<CreativeModeTab> CREATIVE_MODE_TAB_RESOURCE_KEY = ResourceKey.create(
            BuiltInRegistries.CREATIVE_MODE_TAB.key(), Identifier.fromNamespaceAndPath(Whim.MOD_ID, "creative_tab")
    );
    public static final CreativeModeTab CREATIVE_MODE_TAB = FabricCreativeModeTab.builder()
            .icon(() -> new ItemStack(Items.TORCHFLOWER))
            .title(Component.translatable("creativeTab.whim"))
            .displayItems((parameters, output) -> {
                output.accept(ItemRegistry.TEST_ITEM);
                output.accept(BlockRegistry.TEST_BLOCK);

                output.accept(BlockRegistry.RED_FUNDOSHI_BLOCK);
                output.accept(BlockRegistry.WHITE_FUNDOSHI_BLOCK);
                output.accept(BlockRegistry.BLACK_BRIEF_BLOCK);
                output.accept(BlockRegistry.WHITE_BRIEF_BLOCK);
                output.accept(BlockRegistry.NUDE_BLOCK);

                output.accept(ItemRegistry.RED_FUNDOSHI);
                output.accept(ItemRegistry.WHITE_FUNDOSHI);
                output.accept(ItemRegistry.BLACK_BRIEF);
                output.accept(ItemRegistry.WHITE_BRIEF);

                output.accept(ItemRegistry.ANUBIS_HELMET);
                output.accept(ItemRegistry.ANUBIS_CHESTPLATE);
                output.accept(ItemRegistry.ANUBIS_LEGGINGS);
                output.accept(ItemRegistry.ANUBIS_BOOTS);
            })
            .build();
    public static void registerCreativeTabs() {
        Whim.LOGGER.info("Registering Tabs");
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, CREATIVE_MODE_TAB_RESOURCE_KEY, CREATIVE_MODE_TAB);
    }
}