package gay.xujun.whim;

import gay.xujun.whim.registry.BlockRegistry;
import gay.xujun.whim.registry.ItemRegistry;
import gay.xujun.whim.registry.WhimTab;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Whim implements ModInitializer {
    public static final String MOD_ID = "whim";
    public static final Logger LOGGER = LoggerFactory.getLogger("Whim");

    @Override
    public void onInitialize() {
        LOGGER.info("Hello Fabric world!");

        ItemRegistry.registerItem();
        BlockRegistry.registerBlock();
        WhimTab.registerCreativeTabs();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            player.sendSystemMessage(Component.literal(player.getName().getString() + "欢迎回到我的世界！"));
        });
    }
}